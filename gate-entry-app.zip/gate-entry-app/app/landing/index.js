// app/landing/index.js
import React from "react";
import LandingScreen from "./LandingScreen";

export default function Page() {
  return <LandingScreen />;
}
