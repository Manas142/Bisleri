// app/security/manual-entry/index.js
import React from "react";
import ManualEntryScreen from "./ManualEntryScreen";

export default function ManualEntryPage() {
  return <ManualEntryScreen />;
}