// app/security/index.js
import React from "react";
import SecurityDashboard from "./SecurityDashboard";

export default function SecurityPage() {
  return <SecurityDashboard />;
}