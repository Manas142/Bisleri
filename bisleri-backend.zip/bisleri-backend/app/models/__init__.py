from .documents import DocumentData, MfabricDeliveryChallanData, MfabricInvoiceData, MfabricTransferOrderRGPData
from .users import UsersMaster, LocationMaster
from .insights import InsightsData